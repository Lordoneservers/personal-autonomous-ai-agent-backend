CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE TABLE IF NOT EXISTS users (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email text NOT NULL UNIQUE,
  password_hash text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  disabled_at timestamptz
);

CREATE TABLE IF NOT EXISTS google_drive_connections (
  user_id uuid PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  google_email text,
  encrypted_refresh_token text NOT NULL,
  token_iv text NOT NULL,
  token_tag text NOT NULL,
  drive_file_id text,
  connected_at timestamptz NOT NULL DEFAULT now(),
  last_sync_at timestamptz
);

CREATE TABLE IF NOT EXISTS oauth_states (
  state_hash text PRIMARY KEY,
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  expires_at timestamptz NOT NULL
);

CREATE TABLE IF NOT EXISTS memories (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  category text NOT NULL CHECK (category IN (
    'PERSONAL_MEMORY','PROFESSIONAL_MEMORY','PROJECT_MEMORY','RELATIONSHIP_MEMORY',
    'OPERATIONAL_MEMORY','EPISODIC_MEMORY','SEMANTIC_MEMORY','PREFERENCE_MEMORY',
    'SECURITY_AND_PERMISSION_MEMORY','USER_DEFINED_RULES','TEMPORARY_TASK_CONTEXT'
  )),
  content text NOT NULL,
  source text NOT NULL,
  confidence numeric(4,3) NOT NULL DEFAULT 0.700 CHECK (confidence >= 0 AND confidence <= 1),
  verification_status text NOT NULL DEFAULT 'unverified'
    CHECK (verification_status IN ('confirmed','verified','observed','inferred','unverified')),
  sensitivity text NOT NULL DEFAULT 'normal'
    CHECK (sensitivity IN ('normal','sensitive','restricted')),
  retention_policy text NOT NULL DEFAULT 'until_user_deletes',
  user_confirmed boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  deleted_at timestamptz
);
CREATE INDEX IF NOT EXISTS memories_user_category_idx ON memories(user_id, category) WHERE deleted_at IS NULL;
CREATE INDEX IF NOT EXISTS memories_user_updated_idx ON memories(user_id, updated_at DESC) WHERE deleted_at IS NULL;
CREATE INDEX IF NOT EXISTS memories_content_fts_idx ON memories USING gin(to_tsvector('simple', content)) WHERE deleted_at IS NULL;

CREATE TABLE IF NOT EXISTS audit_logs (
  id bigserial PRIMARY KEY,
  user_id uuid REFERENCES users(id) ON DELETE SET NULL,
  action text NOT NULL,
  resource_type text NOT NULL,
  resource_id text,
  outcome text NOT NULL,
  ip_hash text,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS audit_logs_user_created_idx ON audit_logs(user_id, created_at DESC);

CREATE TABLE IF NOT EXISTS backup_runs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  provider text NOT NULL DEFAULT 'google_drive_appdata',
  drive_file_id text,
  checksum_sha256 text NOT NULL,
  memory_count integer NOT NULL,
  status text NOT NULL CHECK (status IN ('started','completed','failed')),
  created_at timestamptz NOT NULL DEFAULT now()
);

-- RLS is enabled as defense-in-depth. The API uses a non-public DB role and
-- enforces ownership in every query; never expose this schema directly to anon clients.
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE google_drive_connections ENABLE ROW LEVEL SECURITY;
ALTER TABLE oauth_states ENABLE ROW LEVEL SECURITY;
ALTER TABLE memories ENABLE ROW LEVEL SECURITY;
ALTER TABLE audit_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE backup_runs ENABLE ROW LEVEL SECURITY;
