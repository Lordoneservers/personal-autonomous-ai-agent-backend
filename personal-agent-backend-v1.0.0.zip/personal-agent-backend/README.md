# Personal Autonomous AI Agent — Backend v1.0.0

Backend foundation for the previously created ChatGPT plugin. Stack: Node.js 22, Fastify 5, TypeScript, PostgreSQL, Argon2id, short-lived JWT access tokens, Google OAuth 2.0, Google Drive `appDataFolder`, AES-256-GCM encryption.

## Important architecture decision: Google Drive memory
Google Drive is the **encrypted portable memory vault and backup/restore target**, not a relational database. PostgreSQL is the live operational store and search index. Each account gets one private `appDataFolder` file named `personal-agent-memory-vault.enc`. The file is encrypted before upload; Drive cannot read its contents. This avoids putting the whole memory system into a fragile single JSON file while still allowing recovery from Drive.

Only `drive.appdata`, `openid`, and `email` scopes are requested. No broad access to the user's Drive files. Refresh tokens are encrypted at rest using AES-256-GCM. The encryption key must be stored in the hosting provider's secret manager and backed up separately. Losing it means the Drive vault cannot be decrypted.

## Included
- Email/password registration and login (Argon2id).
- Authenticated API routes and short-lived JWT.
- Google Drive OAuth connect/status/disconnect.
- Per-user encrypted Drive vault backup and restore.
- Structured memory records with provenance, confidence, verification, sensitivity, retention, and user confirmation.
- Search by category and PostgreSQL full-text/substring matching.
- Soft-delete and audit logging.
- Dockerfile, docker-compose, SQL migration, environment template.

## Not yet included
WhatsApp/SMS/telephony gateways, Android/Windows agents, background schedulers, model-provider orchestration, semantic embeddings/vector retrieval, passkeys/MFA, refresh-token rotation for API sessions, admin console, multi-tenant organization roles, and production deployment. These require their own providers, credentials, and security review. No integration is represented as connected until its OAuth/API setup is completed.

## Local development
1. Install Node.js 22 and Docker.
2. `cp .env.example .env`
3. Generate secrets:
   - `openssl rand -base64 32` for `DATA_ENCRYPTION_KEY`.
   - Use independent random 32+ character values for `JWT_SECRET` and `OAUTH_STATE_SECRET`.
4. Configure Google Cloud:
   - Create/select a Google Cloud project.
   - Enable Google Drive API.
   - Configure OAuth consent screen.
   - Create OAuth client type **Web application**.
   - Add the exact redirect URI from `GOOGLE_REDIRECT_URI`.
   - Put client ID/secret in `.env`.
   - During development add the Google account as a test user if the consent screen is in testing.
5. `docker compose up -d postgres`
6. `npm install`
7. `npm run migrate`
8. `npm run dev`
9. Check `GET http://localhost:8080/health`.

## First account and Drive connection
- `POST /v1/auth/register` with `{ "email":"...", "password":"at-least-12-characters" }`.
- Use returned access token as `Authorization: Bearer <token>`.
- Call `GET /v1/integrations/google-drive/connect` with the access token in the Authorization header. The API returns `{ authorizationUrl }`; redirect the browser to that URL from the authenticated frontend. Never put bearer tokens in query strings.
- Complete Google's consent screen. Check `/v1/integrations/google-drive/status`.
- Save a memory with `POST /v1/memories`, then call `POST /v1/memories/backup`.
- `POST /v1/memories/restore` restores missing records from the encrypted vault. It is idempotent by memory ID.

## API overview
- `GET /health`
- `POST /v1/auth/register`
- `POST /v1/auth/login`
- `GET /v1/account/me`
- `GET /v1/integrations/google-drive/status`
- `GET /v1/integrations/google-drive/connect`
- `GET /v1/integrations/google-drive/callback`
- `DELETE /v1/integrations/google-drive`
- `POST /v1/memories`
- `GET /v1/memories?q=&category=&limit=`
- `DELETE /v1/memories/:id` (soft delete)
- `POST /v1/memories/backup`
- `POST /v1/memories/restore`

## Production hardening checklist
- Terminate TLS at a trusted proxy; set `COOKIE_SECURE=true` if cookie sessions are added.
- Store secrets in a managed secret store, never in Git.
- Use a dedicated least-privilege PostgreSQL role; do not expose the database directly to public clients.
- Add API refresh sessions with rotation/revocation, MFA/passkeys, CSRF controls for cookie auth, per-route rate limits, and anomaly alerts.
- Use a queue/worker for retries and scheduled backups; avoid retrying non-idempotent writes blindly.
- Add semantic embeddings only after selecting an embedding model and documenting retention/data transfer.
- Run dependency audit, integration tests, restore drills, and penetration testing before production.
- Configure Google OAuth consent screen and publish/verify the app as required by Google's current policies.
