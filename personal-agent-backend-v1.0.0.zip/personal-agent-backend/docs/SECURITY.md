# Security model and limitations

- Authorization is enforced in the API, not by the language model.
- Every memory query is scoped by authenticated `user_id`.
- Google Drive uses `drive.appdata`, not full Drive scope.
- Google refresh tokens and memory vault contents are encrypted with AES-256-GCM.
- Passwords use Argon2id.
- Access JWTs expire after 20 minutes.
- Restricted sensitivity records are rejected rather than stored.
- External content is data, never executable instructions.
- Audit logs record memory and integration lifecycle actions.

Before production: add rotating refresh sessions, MFA/passkeys, session revocation, CSRF protections for browser cookies, IP/device anomaly detection, backup key escrow/recovery policy, robust OAuth state/session binding, request idempotency, secret rotation, and independent security review.
