# Google Drive memory design

## Data flow
1. Agent writes structured memory to PostgreSQL.
2. Backup operation serializes only the authenticated user's active memory records.
3. The server encrypts the JSON payload using AES-256-GCM.
4. It uploads one opaque encrypted file to Google's hidden `appDataFolder`.
5. Restore downloads that file, authenticates/decrypts it, validates schema version, and inserts only missing IDs.

## Why not use Drive as the only database?
Drive is excellent for durable user-controlled file storage and portability, but not for concurrent transactional updates, record-level queries, or reliable semantic retrieval. PostgreSQL remains the live store; Drive is the encrypted recovery vault. For cross-device continuity, deploy the same API and database centrally, then use Drive backup/restore as the user's portable recovery copy.

## Important
The Google account is not connected by generating this source code. The owner must configure OAuth credentials and complete Google's consent flow. The Drive API is disabled/unavailable as a direct ChatGPT connector in the current workspace, so this backend uses Google's official OAuth and Drive API independently.
