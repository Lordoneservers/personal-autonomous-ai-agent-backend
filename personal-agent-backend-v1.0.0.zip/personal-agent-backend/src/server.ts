import Fastify from 'fastify';
import cors from '@fastify/cors';
import helmet from '@fastify/helmet';
import rateLimit from '@fastify/rate-limit';
import { randomBytes, createHash } from 'node:crypto';
import argon2 from 'argon2';
import { SignJWT } from 'jose';
import { z } from 'zod';
import { env } from './config.js';
import { pool, audit } from './db.js';
import { authenticate, issueToken, userIdOf } from './auth.js';
import { createDriveAuthorizationUrl, completeGoogleOAuth, saveDriveConnection, disconnectDrive } from './google-drive.js';
import { saveMemory, searchMemories, softDeleteMemory, backupToDrive, restoreFromDrive } from './memory.js';

const app = Fastify({logger:true, trustProxy:false, bodyLimit:256*1024});
await app.register(helmet);
await app.register(cors,{origin:false,credentials:true});
await app.register(rateLimit,{max:100,timeWindow:'1 minute'});
app.get('/health',async()=>({status:'ok',service:'personal-agent-api',version:'1.0.0'}));

app.post('/v1/auth/register',async(req,reply)=>{
  const body=z.object({email:z.string().email().max(254),password:z.string().min(12).max(128)}).parse(req.body);
  const hash=await argon2.hash(body.password,{type:argon2.argon2id});
  try {
    const {rows}=await pool.query('INSERT INTO users(email,password_hash) VALUES(lower($1),$2) RETURNING id,email',[body.email,hash]);
    const token=await issueToken(rows[0].id);
    await audit(rows[0].id,'auth.register','user',rows[0].id,'success');
    return reply.code(201).send({user:rows[0],accessToken:token,expiresIn:1200});
  } catch(e) {
    if ((e as {code?:string}).code==='23505') return reply.code(409).send({error:'email_already_registered'});
    throw e;
  }
});
app.post('/v1/auth/login',async(req,reply)=>{
  const body=z.object({email:z.string().email(),password:z.string().min(1)}).parse(req.body);
  const {rows}=await pool.query('SELECT id,email,password_hash,disabled_at FROM users WHERE email=lower($1)',[body.email]);
  const u=rows[0];
  if(!u || u.disabled_at || !(await argon2.verify(u.password_hash,body.password))) return reply.code(401).send({error:'invalid_credentials'});
  await audit(u.id,'auth.login','user',u.id,'success');
  return {user:{id:u.id,email:u.email},accessToken:await issueToken(u.id),expiresIn:1200};
});

app.get('/v1/integrations/google-drive/status',{preHandler:authenticate},async(req)=>{
  const {rows}=await pool.query('SELECT google_email,connected_at,last_sync_at FROM google_drive_connections WHERE user_id=$1',[userIdOf(req)]);
  return {connected:!!rows[0],...(rows[0]??{})};
});
app.get('/v1/integrations/google-drive/connect',{preHandler:authenticate},async(req,reply)=>{
  const userId=userIdOf(req);
  const state=randomBytes(32).toString('base64url');
  const stateHash=createHash('sha256').update(state).digest('hex');
  await pool.query('DELETE FROM oauth_states WHERE expires_at<now()');
  await pool.query('INSERT INTO oauth_states(state_hash,user_id,expires_at) VALUES($1,$2,now()+interval \'10 minutes\')',[stateHash,userId]);
  return { authorizationUrl: createDriveAuthorizationUrl(state), expiresInSeconds: 600 };
});
app.get('/v1/integrations/google-drive/callback',async(req,reply)=>{
  const q=z.object({code:z.string(),state:z.string()}).safeParse(req.query);
  if(!q.success) return reply.code(400).send({error:'invalid_oauth_callback'});
  const stateHash=createHash('sha256').update(q.data.state).digest('hex');
  const {rows}=await pool.query('DELETE FROM oauth_states WHERE state_hash=$1 AND expires_at>now() RETURNING user_id',[stateHash]);
  if(!rows[0]) return reply.code(400).send({error:'invalid_or_expired_oauth_state'});
  try {
    const account=await completeGoogleOAuth(q.data.code);
    await saveDriveConnection(rows[0].user_id,account.email,account.refreshToken);
    await audit(rows[0].user_id,'google_drive.connect','integration',account.email,'success');
    return reply.type('text/html').send('<!doctype html><html lang="en"><meta charset="utf-8"><title>Connected</title><body><h2>Google Drive connected</h2><p>You can close this window and return to the agent.</p></body></html>');
  } catch(e) {
    req.log.error(e);
    return reply.code(500).send({error:'google_drive_connection_failed'});
  }
});
app.delete('/v1/integrations/google-drive',{preHandler:authenticate},async(req)=>{
  const uid=userIdOf(req); await disconnectDrive(uid); await audit(uid,'google_drive.disconnect','integration',null,'success'); return {disconnected:true};
});

app.post('/v1/memories',{preHandler:authenticate},async(req,reply)=>{
  try { return reply.code(201).send(await saveMemory(userIdOf(req),req.body)); }
  catch(e) { if(e instanceof Error && e.message==='restricted_memory_not_stored') return reply.code(422).send({error:e.message}); throw e; }
});
app.get('/v1/memories',{preHandler:authenticate},async(req)=>{
  const q=z.object({q:z.string().max(500).default(''),category:z.string().optional(),limit:z.coerce.number().int().min(1).max(100).default(20)}).parse(req.query);
  return {items:await searchMemories(userIdOf(req),q.q,q.category,q.limit)};
});
app.delete('/v1/memories/:id',{preHandler:authenticate},async(req,reply)=>{
  const {id}=z.object({id:z.string().uuid()}).parse(req.params);
  const ok=await softDeleteMemory(userIdOf(req),id);
  return ok?{deleted:true}:reply.code(404).send({error:'memory_not_found'});
});
app.post('/v1/memories/backup',{preHandler:authenticate},async(req,reply)=>{
  try { return await backupToDrive(userIdOf(req)); }
  catch(e) { req.log.error(e); return reply.code(409).send({error:'backup_failed_or_drive_not_connected'}); }
});
app.post('/v1/memories/restore',{preHandler:authenticate},async(req,reply)=>{
  try { return await restoreFromDrive(userIdOf(req)); }
  catch(e) { req.log.error(e); return reply.code(409).send({error:'restore_failed_or_drive_vault_missing'}); }
});

app.get('/v1/account/me',{preHandler:authenticate},async(req)=>{
  const {rows}=await pool.query('SELECT id,email,created_at FROM users WHERE id=$1',[userIdOf(req)]);
  return rows[0]??null;
});
app.setErrorHandler((error,req,reply)=>{
  req.log.error(error);
  if(error instanceof z.ZodError) return reply.code(400).send({error:'validation_error',details:error.issues.map(i=>({path:i.path,message:i.message}))});
  return reply.code(500).send({error:'internal_server_error'});
});
const address=await app.listen({port:env.PORT,host:env.HOST});
app.log.info(`Personal Agent API listening at ${address}`);
process.on('SIGTERM',async()=>{await app.close();await pool.end();process.exit(0);});
