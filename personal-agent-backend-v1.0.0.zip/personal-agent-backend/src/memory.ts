import { pool, audit } from './db.js';
import { encrypt, decrypt, sha256 } from './crypto.js';
import { uploadEncryptedVault, downloadEncryptedVault } from './google-drive.js';
import { z } from 'zod';

const categories = ['PERSONAL_MEMORY','PROFESSIONAL_MEMORY','PROJECT_MEMORY','RELATIONSHIP_MEMORY','OPERATIONAL_MEMORY','EPISODIC_MEMORY','SEMANTIC_MEMORY','PREFERENCE_MEMORY','SECURITY_AND_PERMISSION_MEMORY','USER_DEFINED_RULES','TEMPORARY_TASK_CONTEXT'] as const;
const inputSchema = z.object({
  category:z.enum(categories), content:z.string().min(1).max(12000), source:z.string().min(1).max(500),
  confidence:z.number().min(0).max(1).default(0.7),
  verificationStatus:z.enum(['confirmed','verified','observed','inferred','unverified']).default('unverified'),
  sensitivity:z.enum(['normal','sensitive','restricted']).default('normal'),
  retentionPolicy:z.string().max(100).default('until_user_deletes'),
  userConfirmed:z.boolean().default(false)
});
export async function saveMemory(userId:string, raw:unknown) {
  const m = inputSchema.parse(raw);
  if (m.sensitivity === 'restricted') throw new Error('restricted_memory_not_stored');
  const { rows } = await pool.query(
    `INSERT INTO memories(user_id,category,content,source,confidence,verification_status,sensitivity,retention_policy,user_confirmed)
     VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9) RETURNING *`,
    [userId,m.category,m.content,m.source,m.confidence,m.verificationStatus,m.sensitivity,m.retentionPolicy,m.userConfirmed]
  );
  await audit(userId,'memory.create','memory',rows[0].id,'success');
  return rows[0];
}
export async function searchMemories(userId:string, q:string, category?:string, limit=20) {
  const { rows } = await pool.query(
    `SELECT id,category,content,source,confidence,verification_status,sensitivity,user_confirmed,created_at,updated_at
     FROM memories WHERE user_id=$1 AND deleted_at IS NULL
     AND ($2::text IS NULL OR category=$2)
     AND ($3='' OR to_tsvector('simple',content) @@ plainto_tsquery('simple',$3) OR content ILIKE '%'||$3||'%')
     ORDER BY CASE WHEN $3='' THEN 0 ELSE ts_rank(to_tsvector('simple',content),plainto_tsquery('simple',$3)) END DESC, updated_at DESC
     LIMIT $4`,[userId,category ?? null,q,Math.min(Math.max(limit,1),100)]
  );
  return rows;
}
export async function softDeleteMemory(userId:string,id:string) {
  const r = await pool.query('UPDATE memories SET deleted_at=now(),updated_at=now() WHERE user_id=$1 AND id=$2 AND deleted_at IS NULL RETURNING id',[userId,id]);
  if (!r.rowCount) return false;
  await audit(userId,'memory.delete','memory',id,'success');
  return true;
}
export async function backupToDrive(userId:string) {
  const { rows } = await pool.query(
    `SELECT id,category,content,source,confidence,verification_status,sensitivity,retention_policy,user_confirmed,created_at,updated_at
     FROM memories WHERE user_id=$1 AND deleted_at IS NULL ORDER BY created_at`,[userId]
  );
  const data = JSON.stringify({schemaVersion:1,exportedAt:new Date().toISOString(),memories:rows});
  const enc = encrypt(data);
  const envelope = JSON.stringify({version:1,algorithm:'AES-256-GCM',iv:enc.iv,tag:enc.tag,ciphertext:enc.ciphertext});
  const checksum = sha256(envelope);
  const run = await pool.query(
    `INSERT INTO backup_runs(user_id,checksum_sha256,memory_count,status) VALUES($1,$2,$3,'started') RETURNING id`,
    [userId,checksum,rows.length]
  );
  try {
    const fileId = await uploadEncryptedVault(userId,envelope);
    await pool.query(`UPDATE backup_runs SET drive_file_id=$2,status='completed' WHERE id=$1`,[run.rows[0].id,fileId]);
    await audit(userId,'memory.drive_backup','backup',fileId,'success');
    return {backupId:run.rows[0].id,fileId,memoryCount:rows.length,checksum};
  } catch (e) {
    await pool.query(`UPDATE backup_runs SET status='failed' WHERE id=$1`,[run.rows[0].id]);
    await audit(userId,'memory.drive_backup','backup',null,'failed');
    throw e;
  }
}
export async function restoreFromDrive(userId:string) {
  const envelopeText = await downloadEncryptedVault(userId);
  if (!envelopeText) throw new Error('drive_vault_not_found');
  const env = JSON.parse(envelopeText) as {version:number;algorithm:string;iv:string;tag:string;ciphertext:string};
  if (env.version !== 1 || env.algorithm !== 'AES-256-GCM') throw new Error('unsupported_vault_format');
  const plain = decrypt(env.ciphertext,env.iv,env.tag);
  const parsed = JSON.parse(plain) as {schemaVersion:number;memories:Array<Record<string,unknown>>};
  if (parsed.schemaVersion !== 1 || !Array.isArray(parsed.memories)) throw new Error('invalid_vault_payload');
  let restored = 0;
  for (const m of parsed.memories) {
    await pool.query(
      `INSERT INTO memories(id,user_id,category,content,source,confidence,verification_status,sensitivity,retention_policy,user_confirmed,created_at,updated_at)
       VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12) ON CONFLICT(id) DO NOTHING`,
      [m.id,userId,m.category,m.content,m.source,m.confidence,m.verification_status,m.sensitivity,m.retention_policy,m.user_confirmed,m.created_at,m.updated_at]
    );
    restored++;
  }
  await audit(userId,'memory.drive_restore','backup',null,'success');
  return {restored};
}
