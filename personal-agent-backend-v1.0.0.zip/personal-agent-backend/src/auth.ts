import type { FastifyRequest, FastifyReply } from 'fastify';
import { SignJWT, jwtVerify } from 'jose';
import { env } from './config.js';
const secret = new TextEncoder().encode(env.JWT_SECRET);
export async function issueToken(userId: string) {
  return new SignJWT({ sub: userId, typ: 'access' }).setProtectedHeader({ alg:'HS256' })
    .setIssuedAt().setExpirationTime('20m').sign(secret);
}
export async function authenticate(req: FastifyRequest, reply: FastifyReply) {
  const header = req.headers.authorization;
  if (!header?.startsWith('Bearer ')) return reply.code(401).send({ error:'unauthorized' });
  try {
    const { payload } = await jwtVerify(header.slice(7), secret);
    if (payload.typ !== 'access' || typeof payload.sub !== 'string') throw new Error('invalid token');
    (req as FastifyRequest & { userId: string }).userId = payload.sub;
  } catch {
    return reply.code(401).send({ error:'invalid_or_expired_token' });
  }
}
export const userIdOf = (req: FastifyRequest) => (req as FastifyRequest & {userId:string}).userId;
