import { createCipheriv, createDecipheriv, createHash, randomBytes } from 'node:crypto';
import { env } from './config.js';
const key = Buffer.from(env.DATA_ENCRYPTION_KEY, 'base64');
if (key.length !== 32) throw new Error('DATA_ENCRYPTION_KEY must decode to exactly 32 bytes');
export function encrypt(plain: string) {
  const iv = randomBytes(12);
  const cipher = createCipheriv('aes-256-gcm', key, iv);
  const ciphertext = Buffer.concat([cipher.update(plain, 'utf8'), cipher.final()]);
  return { ciphertext: ciphertext.toString('base64'), iv: iv.toString('base64'), tag: cipher.getAuthTag().toString('base64') };
}
export function decrypt(ciphertext: string, iv: string, tag: string) {
  const decipher = createDecipheriv('aes-256-gcm', key, Buffer.from(iv,'base64'));
  decipher.setAuthTag(Buffer.from(tag,'base64'));
  return Buffer.concat([decipher.update(Buffer.from(ciphertext,'base64')), decipher.final()]).toString('utf8');
}
export const sha256 = (data: Buffer | string) => createHash('sha256').update(data).digest('hex');
