import { google } from 'googleapis';
import { env } from './config.js';
import { pool } from './db.js';
import { decrypt, encrypt } from './crypto.js';

function oauthClient() {
  if (!env.GOOGLE_CLIENT_ID || !env.GOOGLE_CLIENT_SECRET) throw new Error('Google OAuth is not configured');
  return new google.auth.OAuth2(env.GOOGLE_CLIENT_ID, env.GOOGLE_CLIENT_SECRET, env.GOOGLE_REDIRECT_URI);
}
export function createDriveAuthorizationUrl(state: string) {
  return oauthClient().generateAuthUrl({
    access_type:'offline', prompt:'consent', state,
    scope:['openid','email','https://www.googleapis.com/auth/drive.appdata']
  });
}
export async function completeGoogleOAuth(code: string) {
  const client = oauthClient();
  const { tokens } = await client.getToken(code);
  if (!tokens.refresh_token) throw new Error('Google did not return a refresh token; revoke the app grant and reconnect with consent');
  client.setCredentials(tokens);
  const oauth2 = google.oauth2({version:'v2', auth:client});
  const profile = await oauth2.userinfo.get();
  if (!profile.data.email) throw new Error('Google account email unavailable');
  return { email: profile.data.email, refreshToken: tokens.refresh_token };
}
async function driveForUser(userId: string) {
  const { rows } = await pool.query(
    'SELECT encrypted_refresh_token,token_iv,token_tag FROM google_drive_connections WHERE user_id=$1', [userId]
  );
  if (!rows[0]) throw new Error('google_drive_not_connected');
  const refreshToken = decrypt(rows[0].encrypted_refresh_token, rows[0].token_iv, rows[0].token_tag);
  const auth = oauthClient();
  auth.setCredentials({refresh_token:refreshToken});
  return google.drive({version:'v3', auth});
}
export async function saveDriveConnection(userId:string,email:string,refreshToken:string) {
  const enc = encrypt(refreshToken);
  await pool.query(
    `INSERT INTO google_drive_connections(user_id,google_email,encrypted_refresh_token,token_iv,token_tag)
     VALUES($1,$2,$3,$4,$5)
     ON CONFLICT(user_id) DO UPDATE SET google_email=EXCLUDED.google_email,
     encrypted_refresh_token=EXCLUDED.encrypted_refresh_token,token_iv=EXCLUDED.token_iv,
     token_tag=EXCLUDED.token_tag,connected_at=now()`,
    [userId,email,enc.ciphertext,enc.iv,enc.tag]
  );
}
export async function uploadEncryptedVault(userId:string, payload:string) {
  const drive = await driveForUser(userId);
  const { rows } = await pool.query('SELECT drive_file_id FROM google_drive_connections WHERE user_id=$1',[userId]);
  const fileId = rows[0]?.drive_file_id as string | null;
  const media = { mimeType:'application/octet-stream', body: Buffer.from(payload,'utf8') };
  let id = fileId;
  if (id) {
    try {
      await drive.files.update({fileId:id, media, fields:'id'});
    } catch (e: unknown) {
      const status = (e as {code?:number}).code;
      if (status !== 404) throw e;
      id = null;
    }
  }
  if (!id) {
    const created = await drive.files.create({
      requestBody:{name:'personal-agent-memory-vault.enc', mimeType:'application/octet-stream', parents:['appDataFolder']},
      media, fields:'id'
    });
    id = created.data.id ?? null;
    if (!id) throw new Error('Drive did not return file id');
    await pool.query('UPDATE google_drive_connections SET drive_file_id=$2 WHERE user_id=$1',[userId,id]);
  }
  await pool.query('UPDATE google_drive_connections SET last_sync_at=now() WHERE user_id=$1',[userId]);
  return id;
}
export async function downloadEncryptedVault(userId:string) {
  const drive = await driveForUser(userId);
  const { rows } = await pool.query('SELECT drive_file_id FROM google_drive_connections WHERE user_id=$1',[userId]);
  const id = rows[0]?.drive_file_id as string | null;
  if (!id) return null;
  const result = await drive.files.get({fileId:id, alt:'media'}, {responseType:'arraybuffer'});
  return Buffer.from(result.data as ArrayBuffer).toString('utf8');
}
export async function disconnectDrive(userId:string) {
  await pool.query('DELETE FROM google_drive_connections WHERE user_id=$1',[userId]);
}
