import pg from 'pg';
import { env } from './config.js';
export const pool = new pg.Pool({ connectionString: env.DATABASE_URL, max: 10, idleTimeoutMillis: 30_000 });
pool.on('error', err => console.error('Unexpected PostgreSQL pool error', err));
export async function audit(userId: string, action: string, type: string, resourceId: string | null, outcome: string) {
  await pool.query(
    `INSERT INTO audit_logs(user_id,action,resource_type,resource_id,outcome)
     VALUES($1,$2,$3,$4,$5)`, [userId, action, type, resourceId, outcome]
  );
}
